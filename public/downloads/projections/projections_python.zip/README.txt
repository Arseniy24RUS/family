Новые алгоритмы платформы 1.2.1. Нужен Python 3.11+ и NumPy.
python -m pip install -r requirements.txt
python reproduce_projection.py indicator forecast.json
python reproduce_projection.py cohort cohort_package.json

Пример example_synthetic.json полностью синтетический; к России и регионам не относится.
